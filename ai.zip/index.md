# Home - HL7 PT FHIR Implementation Guide: IG de Exemplo Versão 1 | STU1 v1.0.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:http://example.com/fhir/example | *Version*:1.0.0 |
| Active as of 2026-02-26 | *Computable Name*:ExampleIG |

> A especificação aqui documentada é, por enquanto, uma especificação de prova de conceito e não pode ser usada para fins de implementação. Nenhuma responsabilidade pode ser inferida do uso ou mau uso desta especificação, ou de suas consequências.

### Âmbito

Esta publicação serve para demonstrar os mecanismos HL7 FHIR para o projecto Allymed

### Introdução

tal e tal

### Dependências



### IP e Licença

This publication includes IP covered under the following statements.

* This material contains content that is copyright of SNOMED International. Implementers of these specifications must have the appropriate SNOMED CT Affiliate license - for more information contact [https://www.snomed.org/get-snomed](https://www.snomed.org/get-snomed) or [info@snomed.org](mailto:info@snomed.org).

* SNOMED Clinical Terms&reg; (SNOMED CT&reg;): [ClinicalUseDefinition/CipraplexGotas-CUD-contra1](ClinicalUseDefinition-CipraplexGotas-CUD-contra1.md), [ClinicalUseDefinition/CipraplexGotas-CUD-contra2](ClinicalUseDefinition-CipraplexGotas-CUD-contra2.md)... Show 12 more, [ClinicalUseDefinition/CipraplexGotas-CUD-contra3](ClinicalUseDefinition-CipraplexGotas-CUD-contra3.md), [ClinicalUseDefinition/CipraplexGotas-CUD-ind1](ClinicalUseDefinition-CipraplexGotas-CUD-ind1.md), [ClinicalUseDefinition/CipraplexGotas-CUD-ind2](ClinicalUseDefinition-CipraplexGotas-CUD-ind2.md), [ClinicalUseDefinition/CipraplexGotas-CUD-ind3](ClinicalUseDefinition-CipraplexGotas-CUD-ind3.md), [ClinicalUseDefinition/CipraplexGotas-CUD-ind4](ClinicalUseDefinition-CipraplexGotas-CUD-ind4.md), [ClinicalUseDefinition/CipraplexGotas-CUD-ind5](ClinicalUseDefinition-CipraplexGotas-CUD-ind5.md), [ClinicalUseDefinition/CipraplexGotas-CUD-int1](ClinicalUseDefinition-CipraplexGotas-CUD-int1.md), [ClinicalUseDefinition/CipraplexGotas-CUD-int2](ClinicalUseDefinition-CipraplexGotas-CUD-int2.md), [ClinicalUseDefinition/CipraplexGotas-CUD-int3](ClinicalUseDefinition-CipraplexGotas-CUD-int3.md), [ClinicalUseDefinition/LorazepamBluepharma05mg-CUD](ClinicalUseDefinition-LorazepamBluepharma05mg-CUD.md), [ClinicalUseDefinition/LorazepamBluepharma05mg-CUD1](ClinicalUseDefinition-LorazepamBluepharma05mg-CUD1.md) and [ClinicalUseDefinition/LorazepamBluepharma05mg-CUD2](ClinicalUseDefinition-LorazepamBluepharma05mg-CUD2.md)


* This material derives from the HL7 Terminology (THO). THO is copyright ©1989+ Health Level Seven International and is made available under the CC0 designation. For more licensing information see: [https://terminology.hl7.org/license.html](https://terminology.hl7.org/license.html)

* [RoleClass](http://terminology.hl7.org/7.1.0/CodeSystem-v3-RoleClass.html): [Cipralex [Escitalopram] 20 mg/ml Gotas orais, solução](MedicationKnowledge-Cipralex-20-mgml-Gotas-orais-solucao.md), [Lorazepam Bluepharma [Lorazepam] 0,5 mg Comprimido](MedicationKnowledge-LorazepamBluepharma05mg.md) and [MedicationKnowledgePDH](StructureDefinition-MedicationKnowledgePDH.md)


### Autores e contribuidores

| | | | |
| :--- | :--- | :--- | :--- |
| Autor | João Almeida | PDH /VC | joaofilipe90 at gmail |
| Autor | xxx |  | dssd |
| Autor | asdasd | asdasd | asdas |
| Autor | asdasd |  | dasda |

